﻿namespace TrackerUI
{
    partial class CreateTournamentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            entryFeeValue = new TextBox();
            entryFeeLabel = new Label();
            createTeamLink = new LinkLabel();
            createPrizeButton = new Button();
            tournamentTeamsListBox = new ListBox();
            tournamentsPlayersLabel = new Label();
            removeSelectedPlayersButton = new Button();
            removeSelectedPrizesButton = new Button();
            prizesLabel = new Label();
            prizesListBox = new ListBox();
            createTournamentButton = new Button();
            headerLabel = new Label();
            tournamentNameLabel = new Label();
            tournamentNameValue = new TextBox();
            selectTeamLabel = new Label();
            selectTeamDropDown = new ComboBox();
            addTeamButton = new Button();
            SuspendLayout();
            // 
            // entryFeeValue
            // 
            entryFeeValue.ForeColor = Color.FromArgb(51, 153, 255);
            entryFeeValue.Location = new Point(102, 160);
            entryFeeValue.Name = "entryFeeValue";
            entryFeeValue.Size = new Size(100, 23);
            entryFeeValue.TabIndex = 12;
            entryFeeValue.Text = "0";
            // 
            // entryFeeLabel
            // 
            entryFeeLabel.ForeColor = Color.FromArgb(51, 153, 255);
            entryFeeLabel.Location = new Point(35, 163);
            entryFeeLabel.Name = "entryFeeLabel";
            entryFeeLabel.Size = new Size(100, 23);
            entryFeeLabel.TabIndex = 13;
            entryFeeLabel.Text = "Entry Fee:";
            // 
            // createTeamLink
            // 
            createTeamLink.Location = new Point(208, 222);
            createTeamLink.Name = "createTeamLink";
            createTeamLink.Size = new Size(67, 23);
            createTeamLink.TabIndex = 9;
            createTeamLink.TabStop = true;
            createTeamLink.Text = "create new";
            createTeamLink.LinkClicked += createTeamLink_LinkClicked;
            // 
            // createPrizeButton
            // 
            createPrizeButton.FlatAppearance.MouseDownBackColor = Color.FromArgb(102, 102, 102);
            createPrizeButton.FlatAppearance.MouseOverBackColor = Color.FromArgb(242, 242, 242);
            createPrizeButton.ForeColor = Color.FromArgb(51, 153, 255);
            createPrizeButton.Location = new Point(66, 350);
            createPrizeButton.Name = "createPrizeButton";
            createPrizeButton.Size = new Size(90, 23);
            createPrizeButton.TabIndex = 7;
            createPrizeButton.Text = "Create prize";
            createPrizeButton.UseVisualStyleBackColor = true;
            createPrizeButton.Click += createPrizeButton_Click;
            // 
            // tournamentTeamsListBox
            // 
            tournamentTeamsListBox.BorderStyle = BorderStyle.FixedSingle;
            tournamentTeamsListBox.FormattingEnabled = true;
            tournamentTeamsListBox.ItemHeight = 15;
            tournamentTeamsListBox.Location = new Point(410, 89);
            tournamentTeamsListBox.Name = "tournamentTeamsListBox";
            tournamentTeamsListBox.Size = new Size(176, 137);
            tournamentTeamsListBox.TabIndex = 6;
            // 
            // tournamentsPlayersLabel
            // 
            tournamentsPlayersLabel.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            tournamentsPlayersLabel.ForeColor = Color.FromArgb(51, 153, 255);
            tournamentsPlayersLabel.Location = new Point(410, 63);
            tournamentsPlayersLabel.Name = "tournamentsPlayersLabel";
            tournamentsPlayersLabel.Size = new Size(100, 23);
            tournamentsPlayersLabel.TabIndex = 5;
            tournamentsPlayersLabel.Text = "Teams / Players";
            // 
            // removeSelectedPlayersButton
            // 
            removeSelectedPlayersButton.FlatAppearance.MouseDownBackColor = Color.FromArgb(102, 102, 102);
            removeSelectedPlayersButton.FlatAppearance.MouseOverBackColor = Color.FromArgb(242, 242, 242);
            removeSelectedPlayersButton.ForeColor = Color.FromArgb(51, 153, 255);
            removeSelectedPlayersButton.Location = new Point(602, 142);
            removeSelectedPlayersButton.Name = "removeSelectedPlayersButton";
            removeSelectedPlayersButton.Size = new Size(75, 23);
            removeSelectedPlayersButton.TabIndex = 4;
            removeSelectedPlayersButton.Text = "remove";
            removeSelectedPlayersButton.UseVisualStyleBackColor = true;
            removeSelectedPlayersButton.Click += removeSelectedPlayersButton_Click;
            // 
            // removeSelectedPrizesButton
            // 
            removeSelectedPrizesButton.FlatAppearance.MouseDownBackColor = Color.FromArgb(102, 102, 102);
            removeSelectedPrizesButton.FlatAppearance.MouseOverBackColor = Color.FromArgb(242, 242, 242);
            removeSelectedPrizesButton.ForeColor = Color.FromArgb(51, 153, 255);
            removeSelectedPrizesButton.Location = new Point(602, 350);
            removeSelectedPrizesButton.Name = "removeSelectedPrizesButton";
            removeSelectedPrizesButton.Size = new Size(75, 23);
            removeSelectedPrizesButton.TabIndex = 1;
            removeSelectedPrizesButton.Text = "remove";
            removeSelectedPrizesButton.UseVisualStyleBackColor = true;
            removeSelectedPrizesButton.Click += removeSelectedPrizesButton_Click;
            // 
            // prizesLabel
            // 
            prizesLabel.ForeColor = Color.FromArgb(51, 153, 255);
            prizesLabel.Location = new Point(225, 105);
            prizesLabel.Name = "prizesLabel";
            prizesLabel.Size = new Size(100, 23);
            prizesLabel.TabIndex = 2;
            // 
            // prizesListBox
            // 
            prizesListBox.BorderStyle = BorderStyle.FixedSingle;
            prizesListBox.FormattingEnabled = true;
            prizesListBox.ItemHeight = 15;
            prizesListBox.Location = new Point(410, 286);
            prizesListBox.Name = "prizesListBox";
            prizesListBox.Size = new Size(176, 137);
            prizesListBox.TabIndex = 3;
            // 
            // createTournamentButton
            // 
            createTournamentButton.FlatAppearance.MouseDownBackColor = Color.FromArgb(102, 102, 102);
            createTournamentButton.FlatAppearance.MouseOverBackColor = Color.FromArgb(242, 242, 242);
            createTournamentButton.ForeColor = Color.FromArgb(51, 153, 255);
            createTournamentButton.Location = new Point(250, 431);
            createTournamentButton.Name = "createTournamentButton";
            createTournamentButton.Size = new Size(147, 23);
            createTournamentButton.TabIndex = 0;
            createTournamentButton.Text = "Create Tournament";
            createTournamentButton.UseVisualStyleBackColor = true;
            createTournamentButton.Click += createTournamentButton_Click;
            // 
            // headerLabel
            // 
            headerLabel.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            headerLabel.ForeColor = Color.FromArgb(51, 153, 255);
            headerLabel.Location = new Point(12, 9);
            headerLabel.Name = "headerLabel";
            headerLabel.Size = new Size(187, 34);
            headerLabel.TabIndex = 16;
            headerLabel.Text = "Create Tournament";
            // 
            // tournamentNameLabel
            // 
            tournamentNameLabel.ForeColor = Color.FromArgb(51, 153, 255);
            tournamentNameLabel.Location = new Point(35, 79);
            tournamentNameLabel.Name = "tournamentNameLabel";
            tournamentNameLabel.Size = new Size(100, 23);
            tournamentNameLabel.TabIndex = 15;
            tournamentNameLabel.Text = "Tournament:";
            // 
            // tournamentNameValue
            // 
            tournamentNameValue.ForeColor = Color.FromArgb(51, 153, 255);
            tournamentNameValue.Location = new Point(35, 105);
            tournamentNameValue.Name = "tournamentNameValue";
            tournamentNameValue.Size = new Size(167, 23);
            tournamentNameValue.TabIndex = 14;
            // 
            // selectTeamLabel
            // 
            selectTeamLabel.ForeColor = Color.FromArgb(51, 153, 255);
            selectTeamLabel.Location = new Point(35, 222);
            selectTeamLabel.Name = "selectTeamLabel";
            selectTeamLabel.Size = new Size(100, 23);
            selectTeamLabel.TabIndex = 11;
            selectTeamLabel.Text = "Select Team";
            selectTeamLabel.Click += selectTeamLabel_Click;
            // 
            // selectTeamDropDown
            // 
            selectTeamDropDown.FormattingEnabled = true;
            selectTeamDropDown.Location = new Point(35, 248);
            selectTeamDropDown.Name = "selectTeamDropDown";
            selectTeamDropDown.Size = new Size(231, 23);
            selectTeamDropDown.TabIndex = 10;
            // 
            // addTeamButton
            // 
            addTeamButton.FlatAppearance.MouseDownBackColor = Color.FromArgb(102, 102, 102);
            addTeamButton.FlatAppearance.MouseOverBackColor = Color.FromArgb(242, 242, 242);
            addTeamButton.ForeColor = Color.FromArgb(51, 153, 255);
            addTeamButton.Location = new Point(66, 309);
            addTeamButton.Name = "addTeamButton";
            addTeamButton.Size = new Size(90, 23);
            addTeamButton.TabIndex = 8;
            addTeamButton.Text = "Add team";
            addTeamButton.UseVisualStyleBackColor = true;
            addTeamButton.Click += addTeamButton_Click;
            // 
            // CreateTournamentForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(781, 466);
            Controls.Add(createTournamentButton);
            Controls.Add(removeSelectedPrizesButton);
            Controls.Add(prizesLabel);
            Controls.Add(prizesListBox);
            Controls.Add(removeSelectedPlayersButton);
            Controls.Add(tournamentsPlayersLabel);
            Controls.Add(tournamentTeamsListBox);
            Controls.Add(createPrizeButton);
            Controls.Add(addTeamButton);
            Controls.Add(createTeamLink);
            Controls.Add(selectTeamDropDown);
            Controls.Add(selectTeamLabel);
            Controls.Add(entryFeeValue);
            Controls.Add(entryFeeLabel);
            Controls.Add(tournamentNameValue);
            Controls.Add(tournamentNameLabel);
            Controls.Add(headerLabel);
            ForeColor = Color.FromArgb(51, 153, 255);
            Name = "CreateTournamentForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox entryFeeValue;
        private Label entryFeeLabel;
        private LinkLabel createTeamLink;
        private Button createPrizeButton;
        private ListBox tournamentTeamsListBox;
        private Label tournamentsPlayersLabel;
        private Button removeSelectedPlayersButton;
        private Button removeSelectedPrizesButton;
        private Label prizesLabel;
        private ListBox prizesListBox;
        private Button createTournamentButton;
        private Label headerLabel;
        private Label tournamentNameLabel;
        private TextBox tournamentNameValue;
        private Label selectTeamLabel;
        private ComboBox selectTeamDropDown;
        private Button addTeamButton;
    }
}