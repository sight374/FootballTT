﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tracker
{
    public enum DatabaseType
    {
        Sql, TextFile
    }
}
